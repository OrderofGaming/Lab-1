// NOTE: Do not redistribute this file. Functions in this namespace are only intended for
// internal TTK usage.

#pragma once

namespace TTK
{
	namespace Internal
	{
		int checkGLEW();
	};
};